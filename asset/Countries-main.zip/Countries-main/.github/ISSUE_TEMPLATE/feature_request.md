---
name: Feature request
about: Suggest an idea or use case
title: Feature
labels: feature request
assignees: ''
---

### Use case for the feature

<!-- please describe precisely where it is useful -->

### Examples or links

<!-- please specify or remove -->
