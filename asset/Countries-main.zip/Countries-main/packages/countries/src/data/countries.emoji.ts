import { TCountryToString } from '../types.ts'
import countriesEmoji from '../../../../dist/minimal/countries.emoji.min.json'

export default countriesEmoji as TCountryToString
